-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: projeto-integrador
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `primeiroNome` varchar(255) DEFAULT NULL,
  `sobrenome` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  `tipo_conta` int DEFAULT NULL,
  KEY `fk_id_tipo_idx` (`id_user`),
  KEY `fk_id_tipo_idx1` (`tipo_conta`),
  CONSTRAINT `fk_id_tipo` FOREIGN KEY (`tipo_conta`) REFERENCES `tipo_conta` (`id_tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Vini','Black','vini@vendedor.com','$2y$10$CMIj2u9t9mWAKXGpT4QLPOLup828zT/I1FZbsqRIgmG8aVyZpz9Ha',2),(2,'Vinicius','Santana','vinicius@cliente.com','$2y$10$0AyawoUzZM1Rey8LnSHI/eyG6XKBJmMoC47vTt4QFO9jpoMy4AaWu',1),(3,'test','teste','teste@teste.com','$2y$10$aOSxzyiKKOvSCa/e5bSZQe/iYhKvtuS0antgrskm5jiQeNx7Y7vt6',1),(4,'asd','fsdfsd','tessste@teste.com','$2y$10$TzzDSW1..owaAkjXYs1QpOY8BYDK43kOcIlmkI1NMcwdsIFERZ.yK',2),(5,'ee','ee','e@e.com','$2y$10$cAzpLZQSe1x6jTqbP2A8Z.OsO2mY8FEMMmLyXmsrNNdptHOUb44Uu',1),(6,'teste ','pi','teste@pi.com','$2y$10$69Qg.tO4.0glTAnF4/SH..JSMv5CMjU7BGhCW0ln.uET85BjpW5hO',2),(7,'tamires','Tamires','tamires@lojista.com','$2y$10$j3KVdZ5HvJO8eFYQX7RFCOyKGY1qr967vZU3EDMOqwW1Ho9law74y',2),(8,'Tamires','tamires','tamires@cliente.com','$2y$10$h8sgVHlb7g.6sjpZEtwZ0OKI63bNGy0GT3okcjpoz7gLhRNKLJeA.',1),(9,'vini','tamires','teste22@email.com','$2y$10$m87G/8kwDMpjVYzOr773e.nfD..MI2K31oLrRqvbVygeLcG5RxYkm',1),(10,'asda','asdas','123@123.com','$2y$10$ZPVdmD9sf8uKP2YtQ2gjyOxLYPk.9kbrA8y9mrjGSEFG24tLF9vBu',1),(11,'qwe','qwe','qwe@eqw.com','$2y$10$am7zmOi38KQS2VPoQgJmoe23JM6aHKWLevWWVpcnMAn2JSGp0Thmq',1),(12,'teste1','teste','apresentacao@email.com','$2y$10$12KmFhLA.l9YUNC1H5fevOdThNrWqWL1wCUt6g2VkPU6E9OCHAAsi',2),(13,'cliente ','teste','cliente@teste.com','$2y$10$u2AQS16zFQ1dsNq2FWXzPegh25gn9gDP11C0HBO/Rl6u59DpOoQSu',1),(14,'Tiago','Claro','tiago@claro.com','$2y$10$jTeNe7DZqno7ObHkUhZItOirGkTj53xE1UUZO.eVf2SKA8.bdPWYK',2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-05 13:01:03
